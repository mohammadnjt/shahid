import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter, Redirect } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Index() {
  const { session, loading } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();

  useEffect(() => {
    checkOnboarding();
  }, [loading, session]);

  const checkOnboarding = async () => {
    if (loading) return;

    try {
      const hasSeenOnboarding = await AsyncStorage.getItem('hasSeenOnboarding');

      if (!hasSeenOnboarding) {
        router.replace('/onboarding');
        return;
      }

      if (!session) {
        router.replace('/auth/login');
        return;
      }

      router.replace('/(tabs)');
    } catch (error) {
      console.error('Error checking onboarding:', error);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}
