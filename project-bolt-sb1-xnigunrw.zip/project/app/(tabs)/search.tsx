import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { supabase, Post, Profile } from '@/lib/supabase';
import { Spacing, BorderRadius, FontSizes, FontWeights, Elevations } from '@/constants/colors';
import { Search as SearchIcon, X, ListFilter as Filter } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

type SearchTab = 'posts' | 'users';

export default function SearchScreen() {
  const { colors } = useTheme();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<SearchTab>('posts');
  const [posts, setPosts] = useState<Post[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    if (query.length > 2) {
      handleSearch();
    } else {
      setPosts([]);
      setUsers([]);
    }
  }, [query, activeTab]);

  const handleSearch = async () => {
    setLoading(true);
    try {
      if (activeTab === 'posts') {
        const { data, error } = await supabase
          .from('posts')
          .select(`
            *,
            profiles:user_id (
              username,
              avatar_url
            )
          `)
          .ilike('content', `%${query}%`)
          .order('created_at', { ascending: false })
          .limit(20);

        if (error) throw error;
        setPosts(data || []);
      } else {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .or(`username.ilike.%${query}%,full_name.ilike.%${query}%`)
          .limit(20);

        if (error) throw error;
        setUsers(data || []);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderPost = ({ item, index }: { item: Post; index: number }) => (
    <Animated.View
      entering={FadeInDown.duration(300).delay(index * 50)}
      style={[
        styles.resultCard,
        { backgroundColor: colors.surface },
        Elevations.sm,
      ]}
    >
      <View style={styles.postHeader}>
        <View style={[styles.smallAvatar, { backgroundColor: colors.primaryContainer }]}>
          {item.profiles?.avatar_url ? (
            <Image
              source={{ uri: item.profiles.avatar_url }}
              style={styles.avatarImage}
            />
          ) : (
            <Text style={[styles.avatarText, { color: colors.primary }]}>
              {item.profiles?.username?.charAt(0).toUpperCase()}
            </Text>
          )}
        </View>
        <Text style={[styles.postUsername, { color: colors.onSurface }]}>
          {item.profiles?.username}
        </Text>
      </View>
      <Text style={[styles.postContent, { color: colors.onSurfaceVariant }]} numberOfLines={3}>
        {item.content}
      </Text>
    </Animated.View>
  );

  const renderUser = ({ item, index }: { item: Profile; index: number }) => (
    <Animated.View
      entering={FadeInDown.duration(300).delay(index * 50)}
      style={[
        styles.resultCard,
        { backgroundColor: colors.surface },
        Elevations.sm,
      ]}
    >
      <View style={styles.userResult}>
        <View style={[styles.avatar, { backgroundColor: colors.primaryContainer }]}>
          {item.avatar_url ? (
            <Image source={{ uri: item.avatar_url }} style={styles.avatarImage} />
          ) : (
            <Text style={[styles.avatarText, { color: colors.primary }]}>
              {item.username?.charAt(0).toUpperCase()}
            </Text>
          )}
        </View>
        <View style={styles.userInfo}>
          <Text style={[styles.username, { color: colors.onSurface }]}>
            {item.username}
          </Text>
          {item.full_name && (
            <Text style={[styles.fullName, { color: colors.onSurfaceVariant }]}>
              {item.full_name}
            </Text>
          )}
          <Text style={[styles.stats, { color: colors.onSurfaceVariant }]}>
            {item.followers_count} followers
          </Text>
        </View>
      </View>
    </Animated.View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.surface }]}>
        <View
          style={[
            styles.searchBar,
            { backgroundColor: colors.surfaceVariant, borderColor: colors.outline },
          ]}
        >
          <SearchIcon size={20} color={colors.onSurfaceVariant} />
          <TextInput
            style={[styles.searchInput, { color: colors.onSurface }]}
            placeholder="Search posts and users..."
            placeholderTextColor={colors.onSurfaceVariant}
            value={query}
            onChangeText={setQuery}
            autoCapitalize="none"
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => setQuery('')}>
              <X size={20} color={colors.onSurfaceVariant} />
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity
          style={[styles.filterButton, { backgroundColor: colors.primaryContainer }]}
          onPress={() => setShowFilters(!showFilters)}
        >
          <Filter size={20} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'posts' && {
              borderBottomColor: colors.primary,
              borderBottomWidth: 2,
            },
          ]}
          onPress={() => setActiveTab('posts')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'posts' ? colors.primary : colors.onSurfaceVariant,
                fontWeight: activeTab === 'posts' ? FontWeights.semibold : FontWeights.regular,
              },
            ]}
          >
            Posts
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'users' && {
              borderBottomColor: colors.primary,
              borderBottomWidth: 2,
            },
          ]}
          onPress={() => setActiveTab('users')}
        >
          <Text
            style={[
              styles.tabText,
              {
                color: activeTab === 'users' ? colors.primary : colors.onSurfaceVariant,
                fontWeight: activeTab === 'users' ? FontWeights.semibold : FontWeights.regular,
              },
            ]}
          >
            Users
          </Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={activeTab === 'posts' ? posts : users}
          renderItem={activeTab === 'posts' ? renderPost : renderUser}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            query.length > 0 ? (
              <View style={styles.emptyContainer}>
                <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>
                  {query.length < 3
                    ? 'Type at least 3 characters to search'
                    : 'No results found'}
                </Text>
              </View>
            ) : (
              <View style={styles.emptyContainer}>
                <SearchIcon size={48} color={colors.onSurfaceVariant} />
                <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>
                  Search for posts and users
                </Text>
              </View>
            )
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingBottom: Spacing.md,
    paddingHorizontal: Spacing.md,
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    height: 48,
    borderRadius: BorderRadius.xl,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
    borderWidth: 1,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSizes.md,
    height: '100%',
  },
  filterButton: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.md,
  },
  tab: {
    flex: 1,
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  tabText: {
    fontSize: FontSizes.md,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  list: {
    padding: Spacing.md,
  },
  resultCard: {
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  postHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  smallAvatar: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.full,
    marginRight: Spacing.xs,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  postUsername: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
  },
  postContent: {
    fontSize: FontSizes.sm,
    lineHeight: 20,
  },
  userResult: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.full,
    marginRight: Spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
  avatarText: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
  },
  userInfo: {
    flex: 1,
  },
  username: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    marginBottom: 2,
  },
  fullName: {
    fontSize: FontSizes.sm,
    marginBottom: 2,
  },
  stats: {
    fontSize: FontSizes.xs,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: Spacing.xxl,
    gap: Spacing.md,
  },
  emptyText: {
    fontSize: FontSizes.md,
    textAlign: 'center',
  },
});
