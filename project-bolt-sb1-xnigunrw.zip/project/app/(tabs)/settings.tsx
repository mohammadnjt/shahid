import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Spacing, BorderRadius, FontSizes, FontWeights, Elevations } from '@/constants/colors';
import {
  Moon,
  Sun,
  Smartphone,
  Bell,
  Fingerprint,
  Globe,
  Shield,
  Info,
  ChevronRight,
} from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function SettingsScreen() {
  const { colors, theme, themeMode, setThemeMode } = useTheme();
  const { user } = useAuth();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(false);

  useEffect(() => {
    if (user) {
      loadPreferences();
    }
  }, [user]);

  const loadPreferences = async () => {
    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setNotificationsEnabled(data.notifications_enabled);
        setBiometricEnabled(data.biometric_enabled);
        setThemeMode(data.theme);
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
    }
  };

  const updatePreference = async (field: string, value: any) => {
    try {
      const { error } = await supabase
        .from('user_preferences')
        .update({ [field]: value })
        .eq('user_id', user!.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating preference:', error);
    }
  };

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'auto') => {
    setThemeMode(newTheme);
    updatePreference('theme', newTheme);
  };

  const handleNotificationsToggle = (value: boolean) => {
    setNotificationsEnabled(value);
    updatePreference('notifications_enabled', value);
  };

  const handleBiometricToggle = (value: boolean) => {
    setBiometricEnabled(value);
    updatePreference('biometric_enabled', value);
  };

  const SettingItem = ({
    icon: Icon,
    title,
    subtitle,
    onPress,
    rightElement,
    delay = 0,
  }: {
    icon: any;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    rightElement?: React.ReactNode;
    delay?: number;
  }) => (
    <Animated.View entering={FadeInDown.duration(300).delay(delay)}>
      <TouchableOpacity
        style={[styles.settingItem, { backgroundColor: colors.surface }, Elevations.sm]}
        onPress={onPress}
        disabled={!onPress}
        activeOpacity={0.7}
      >
        <View style={[styles.iconContainer, { backgroundColor: colors.primaryContainer }]}>
          <Icon size={22} color={colors.primary} />
        </View>
        <View style={styles.settingContent}>
          <Text style={[styles.settingTitle, { color: colors.onSurface }]}>{title}</Text>
          {subtitle && (
            <Text style={[styles.settingSubtitle, { color: colors.onSurfaceVariant }]}>
              {subtitle}
            </Text>
          )}
        </View>
        {rightElement || <ChevronRight size={20} color={colors.onSurfaceVariant} />}
      </TouchableOpacity>
    </Animated.View>
  );

  const ThemeOption = ({
    value,
    label,
    icon: Icon,
  }: {
    value: 'light' | 'dark' | 'auto';
    label: string;
    icon: any;
  }) => (
    <TouchableOpacity
      style={[
        styles.themeOption,
        {
          backgroundColor:
            themeMode === value ? colors.primaryContainer : colors.surface,
          borderColor: themeMode === value ? colors.primary : colors.outline,
        },
      ]}
      onPress={() => handleThemeChange(value)}
      activeOpacity={0.7}
    >
      <Icon
        size={24}
        color={themeMode === value ? colors.primary : colors.onSurfaceVariant}
      />
      <Text
        style={[
          styles.themeLabel,
          {
            color: themeMode === value ? colors.primary : colors.onSurface,
            fontWeight: themeMode === value ? FontWeights.semibold : FontWeights.regular,
          },
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.surface }]}>
        <Text style={[styles.headerTitle, { color: colors.onSurface }]}>Settings</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <Animated.View entering={FadeInDown.duration(400)} style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.onSurfaceVariant }]}>
            APPEARANCE
          </Text>
          <View style={styles.themeContainer}>
            <ThemeOption value="light" label="Light" icon={Sun} />
            <ThemeOption value="dark" label="Dark" icon={Moon} />
            <ThemeOption value="auto" label="Auto" icon={Smartphone} />
          </View>
        </Animated.View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.onSurfaceVariant }]}>
            PREFERENCES
          </Text>

          <SettingItem
            icon={Bell}
            title="Notifications"
            subtitle="Enable push notifications"
            delay={100}
            rightElement={
              <Switch
                value={notificationsEnabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: colors.outline, true: colors.primary }}
                thumbColor={colors.onPrimary}
              />
            }
          />

          <SettingItem
            icon={Fingerprint}
            title="Biometric Authentication"
            subtitle="Use fingerprint or face ID"
            delay={150}
            rightElement={
              <Switch
                value={biometricEnabled}
                onValueChange={handleBiometricToggle}
                trackColor={{ false: colors.outline, true: colors.primary }}
                thumbColor={colors.onPrimary}
              />
            }
          />

          <SettingItem
            icon={Globe}
            title="Language"
            subtitle="English"
            delay={200}
            onPress={() => Alert.alert('Language', 'Language selection coming soon!')}
          />
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.onSurfaceVariant }]}>
            ABOUT
          </Text>

          <SettingItem
            icon={Shield}
            title="Privacy Policy"
            delay={250}
            onPress={() => Alert.alert('Privacy Policy', 'Privacy policy details...')}
          />

          <SettingItem
            icon={Info}
            title="About BeautifulApp"
            subtitle="Version 1.0.0"
            delay={300}
            onPress={() =>
              Alert.alert(
                'BeautifulApp',
                'A beautiful, modern social app built with React Native and Expo.'
              )
            }
          />
        </View>

        <Animated.View entering={FadeInDown.duration(400).delay(350)} style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.onSurfaceVariant }]}>
            Made with care
          </Text>
          <Text style={[styles.footerText, { color: colors.onSurfaceVariant }]}>
            BeautifulApp © 2025
          </Text>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingBottom: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  headerTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
  },
  content: {
    padding: Spacing.md,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    letterSpacing: 1,
    marginBottom: Spacing.md,
    marginLeft: Spacing.xs,
  },
  themeContainer: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  themeOption: {
    flex: 1,
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 2,
    gap: Spacing.xs,
  },
  themeLabel: {
    fontSize: FontSizes.sm,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.xs,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: Spacing.md,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
  },
  settingSubtitle: {
    fontSize: FontSizes.sm,
    marginTop: 2,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
    gap: Spacing.xs,
  },
  footerText: {
    fontSize: FontSizes.sm,
  },
});
