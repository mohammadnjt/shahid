import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  TextInput,
  Modal,
} from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, Post } from '@/lib/supabase';
import { Spacing, BorderRadius, FontSizes, FontWeights, Elevations } from '@/constants/colors';
import { CreditCard as Edit2, Camera, Grid2x2 as Grid, Heart, LogOut } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import Animated, { FadeInDown } from 'react-native-reanimated';

export default function ProfileScreen() {
  const { colors } = useTheme();
  const { user, profile, signOut, refreshProfile } = useAuth();
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [editedBio, setEditedBio] = useState('');

  useEffect(() => {
    if (user) {
      loadUserPosts();
    }
  }, [user]);

  useEffect(() => {
    if (profile) {
      setEditedName(profile.full_name || '');
      setEditedBio(profile.bio || '');
    }
  }, [profile]);

  const loadUserPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUserPosts(data || []);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant photo library access');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        Alert.alert('Success', 'Profile picture updated!');
      }
    } catch (error) {
      console.error('Error picking image:', error);
    }
  };

  const handleUpdateProfile = async () => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: editedName,
          bio: editedBio,
        })
        .eq('id', user!.id);

      if (error) throw error;

      await refreshProfile();
      setEditModalVisible(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error: any) {
      Alert.alert('Error', error.message);
    }
  };

  const handleSignOut = async () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: async () => {
          await signOut();
        },
      },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.surface }]}>
        <Text style={[styles.headerTitle, { color: colors.onSurface }]}>Profile</Text>
        <TouchableOpacity onPress={handleSignOut} style={styles.logoutButton}>
          <LogOut size={22} color={colors.error} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.profileSection}>
          <Animated.View entering={FadeInDown.duration(400)} style={styles.avatarContainer}>
            <View
              style={[
                styles.avatar,
                { backgroundColor: colors.primaryContainer },
                Elevations.md,
              ]}
            >
              {profile?.avatar_url ? (
                <Image source={{ uri: profile.avatar_url }} style={styles.avatarImage} />
              ) : (
                <Text style={[styles.avatarText, { color: colors.primary }]}>
                  {profile?.username?.charAt(0).toUpperCase()}
                </Text>
              )}
            </View>
            <TouchableOpacity
              style={[
                styles.cameraButton,
                { backgroundColor: colors.primary },
                Elevations.sm,
              ]}
              onPress={handlePickImage}
            >
              <Camera size={18} color={colors.onPrimary} />
            </TouchableOpacity>
          </Animated.View>

          <Animated.View entering={FadeInDown.duration(400).delay(100)} style={styles.profileInfo}>
            <Text style={[styles.username, { color: colors.onBackground }]}>
              @{profile?.username}
            </Text>
            {profile?.full_name && (
              <Text style={[styles.fullName, { color: colors.onSurfaceVariant }]}>
                {profile.full_name}
              </Text>
            )}
            {profile?.bio && (
              <Text style={[styles.bio, { color: colors.onSurfaceVariant }]}>
                {profile.bio}
              </Text>
            )}
          </Animated.View>

          <Animated.View
            entering={FadeInDown.duration(400).delay(200)}
            style={styles.statsContainer}
          >
            <View style={styles.stat}>
              <Text style={[styles.statValue, { color: colors.onBackground }]}>
                {profile?.posts_count || 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.onSurfaceVariant }]}>
                Posts
              </Text>
            </View>
            <View style={styles.stat}>
              <Text style={[styles.statValue, { color: colors.onBackground }]}>
                {profile?.followers_count || 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.onSurfaceVariant }]}>
                Followers
              </Text>
            </View>
            <View style={styles.stat}>
              <Text style={[styles.statValue, { color: colors.onBackground }]}>
                {profile?.following_count || 0}
              </Text>
              <Text style={[styles.statLabel, { color: colors.onSurfaceVariant }]}>
                Following
              </Text>
            </View>
          </Animated.View>

          <Animated.View entering={FadeInDown.duration(400).delay(300)}>
            <TouchableOpacity
              style={[styles.editButton, { backgroundColor: colors.primaryContainer }]}
              onPress={() => setEditModalVisible(true)}
              activeOpacity={0.8}
            >
              <Edit2 size={18} color={colors.primary} />
              <Text style={[styles.editButtonText, { color: colors.primary }]}>
                Edit Profile
              </Text>
            </TouchableOpacity>
          </Animated.View>
        </View>

        <View style={styles.postsSection}>
          <View style={styles.sectionHeader}>
            <Grid size={20} color={colors.onSurfaceVariant} />
            <Text style={[styles.sectionTitle, { color: colors.onBackground }]}>
              Your Posts
            </Text>
          </View>

          {userPosts.length > 0 ? (
            <View style={styles.postsGrid}>
              {userPosts.map((post, index) => (
                <Animated.View
                  key={post.id}
                  entering={FadeInDown.duration(300).delay(index * 50)}
                  style={[
                    styles.postCard,
                    { backgroundColor: colors.surface },
                    Elevations.sm,
                  ]}
                >
                  <Text style={[styles.postContent, { color: colors.onSurface }]} numberOfLines={3}>
                    {post.content}
                  </Text>
                  <View style={styles.postStats}>
                    <View style={styles.postStat}>
                      <Heart size={14} color={colors.error} fill={colors.error} />
                      <Text style={[styles.postStatText, { color: colors.onSurfaceVariant }]}>
                        {post.likes_count}
                      </Text>
                    </View>
                  </View>
                </Animated.View>
              ))}
            </View>
          ) : (
            <View style={styles.emptyContainer}>
              <Text style={[styles.emptyText, { color: colors.onSurfaceVariant }]}>
                No posts yet
              </Text>
            </View>
          )}
        </View>
      </ScrollView>

      <Modal
        visible={editModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalContent,
              { backgroundColor: colors.surface },
              Elevations.xl,
            ]}
          >
            <Text style={[styles.modalTitle, { color: colors.onSurface }]}>
              Edit Profile
            </Text>

            <View style={styles.modalInputContainer}>
              <Text style={[styles.modalLabel, { color: colors.onSurfaceVariant }]}>
                Full Name
              </Text>
              <TextInput
                style={[
                  styles.modalInput,
                  {
                    backgroundColor: colors.background,
                    color: colors.onSurface,
                    borderColor: colors.outline,
                  },
                ]}
                value={editedName}
                onChangeText={setEditedName}
                placeholder="Enter your name"
                placeholderTextColor={colors.onSurfaceVariant}
              />
            </View>

            <View style={styles.modalInputContainer}>
              <Text style={[styles.modalLabel, { color: colors.onSurfaceVariant }]}>Bio</Text>
              <TextInput
                style={[
                  styles.modalInput,
                  styles.modalTextArea,
                  {
                    backgroundColor: colors.background,
                    color: colors.onSurface,
                    borderColor: colors.outline,
                  },
                ]}
                value={editedBio}
                onChangeText={setEditedBio}
                placeholder="Tell us about yourself"
                placeholderTextColor={colors.onSurfaceVariant}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: colors.surfaceVariant }]}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={[styles.modalButtonText, { color: colors.onSurface }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: colors.primary }]}
                onPress={handleUpdateProfile}
              >
                <Text style={[styles.modalButtonText, { color: colors.onPrimary }]}>
                  Save
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 50,
    paddingBottom: Spacing.md,
    paddingHorizontal: Spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
  },
  logoutButton: {
    padding: Spacing.xs,
  },
  profileSection: {
    padding: Spacing.lg,
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: Spacing.lg,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: BorderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },
  avatarText: {
    fontSize: 48,
    fontWeight: FontWeights.bold,
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  username: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    marginBottom: Spacing.xs,
  },
  fullName: {
    fontSize: FontSizes.md,
    marginBottom: Spacing.xs,
  },
  bio: {
    fontSize: FontSizes.sm,
    textAlign: 'center',
    paddingHorizontal: Spacing.lg,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: Spacing.xxl,
    marginBottom: Spacing.lg,
  },
  stat: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
  },
  statLabel: {
    fontSize: FontSizes.sm,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.xl,
  },
  editButtonText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
  },
  postsSection: {
    padding: Spacing.md,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
  },
  postsGrid: {
    gap: Spacing.sm,
  },
  postCard: {
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
  },
  postContent: {
    fontSize: FontSizes.sm,
    lineHeight: 20,
    marginBottom: Spacing.sm,
  },
  postStats: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  postStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  postStatText: {
    fontSize: FontSizes.xs,
  },
  emptyContainer: {
    padding: Spacing.xxl,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: FontSizes.md,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
  },
  modalTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    marginBottom: Spacing.lg,
  },
  modalInputContainer: {
    marginBottom: Spacing.md,
  },
  modalLabel: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    marginBottom: Spacing.xs,
  },
  modalInput: {
    borderWidth: 1,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    fontSize: FontSizes.md,
  },
  modalTextArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  modalButton: {
    flex: 1,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
  },
  modalButtonText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
  },
});
